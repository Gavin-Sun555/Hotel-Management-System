#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hotel-ll.h"
node_t *Initialize(void* ch) {
    node_t *head;
    head=(node_t*)calloc(1,sizeof(node_t));
    if(head==NULL){ fprintf(stderr,"Failed to assign memory!\n"); exit(-1); }
    head->next=NULL; head->ch=ch;
    return head;
}

void FreeList(node_t **head) {
    node_t *tmp=NULL; node_t *pHead=*head;
    while(pHead->next!=NULL) { tmp=pHead; pHead=pHead->next; free(tmp); }
    free(pHead);
}
bool IsEmptyList(node_t *head){
    if(head==NULL)
        return true;
    else
        return false;
}
void InsertFirstList(node_t **head,void* insert_char){
    node_t *first;
    first=(node_t*)calloc(1,sizeof(node_t));
    first->ch=insert_char;//
    first->next=*head;
    (*head)=first;//let the head pointer to the new initial point//
}
void InsertLastList(node_t **head,void* insert_char){
    node_t *temp=*head;
    node_t *last=calloc(1,sizeof(node_t));//use temp to trace the last element of the list
    while(temp->next!=NULL){temp=temp->next;};
    last->ch=insert_char;
    last->next=NULL;
    temp->next=last;
}
void DeleteFirstList(node_t **head){
    node_t* first=*head;
    (*head)=first->next;
    free(first);
}
void DeleteLastList(node_t **head){
    node_t *temp=*head;//use temp to trace the last element of the list
    while(temp->next->next!=NULL){temp=temp->next;};
    free(temp->next);
    temp->next=NULL;//WONDER if this writing style is ok.
}
int SizeList(node_t *head){
    if (head==NULL)
        return 0;
    node_t *temp= head;
    int i=1;
    while(temp->next!=NULL){temp=temp->next;i=i+1;};
    return i;

}
int SearchList(node_t **head, void* target){
    int i=0;
    node_t *temp= *head;
    while(temp!=NULL){
        if (temp->ch==target)
            i++;
        temp=temp->next;}
    return i;
}
void SplitList(node_t **head, node_t **tail, int pos){
    int i;
    node_t *temp= *head;
    for(i=0;i<(pos-1);i++){
        temp=temp->next;
    }
    *tail=temp->next;
    temp->next=NULL;
}
void MergeList(node_t **head1, node_t **head2){
    node_t *temp= *head1;
    while(temp->next!=NULL){temp=temp->next;}
    temp->next=*head2;
}
typedef struct _vistorlist{char* firstname;char*givenname;}vistorlist;
node_t* generatevistors(int a){
    srand(time(NULL)+a);
    int first,last;
    node_t* vistor;
    int* random_varible=malloc(sizeof(int));
    vistorlist* vistorlist1=malloc(50* sizeof(vistorlist)) ;
    *vistorlist1=(vistorlist){"Yan","Sun",};
    *(vistorlist1+1)=(vistorlist){"Yihao","Liu"};
    *(vistorlist1+2)=(vistorlist){"Aaron","Smith"};
    *(vistorlist1+3)=(vistorlist){"Abe","Jones"};
    *(vistorlist1+4)=(vistorlist){"Adam","Patel"};
    *(vistorlist1+5)=(vistorlist){"Adan","Davis"};
    *(vistorlist1+6)=(vistorlist){"Adrian","Bell"};
    *(vistorlist1+7)=(vistorlist){"Agustin","Baker"};
    *(vistorlist1+8)=(vistorlist){"Ahmad","Liu"};
    *(vistorlist1+9)=(vistorlist){"Alan","Thomas"};
    *(vistorlist1+10)=(vistorlist){"Albert","Jones"};
    *(vistorlist1+11)=(vistorlist){"Aldo","Roberts"};
    *(vistorlist1+12)=(vistorlist){"Alfredo","Davis"};
    *(vistorlist1+13)=(vistorlist){"Ali","Johnson"};
    *(vistorlist1+14)=(vistorlist){"Allan","Gibson"};
    *(vistorlist1+15)=(vistorlist){"Alton","Wells"};
    *(vistorlist1+16)=(vistorlist){"Andy","Murphy"};
    *(vistorlist1+17)=(vistorlist){"Anibal","Foster"};
    *(vistorlist1+18)=(vistorlist){"Becky","Mills"};
    *(vistorlist1+19)=(vistorlist){"Bert","Hart"};
    *(vistorlist1+20)=(vistorlist){"Brant","Gill"};
    *(vistorlist1+21)=(vistorlist){"Brett","White"};
    *(vistorlist1+22)=(vistorlist){"Chad","Jackson"};
    *(vistorlist1+23)=(vistorlist){"Chang","Green"};
    *(vistorlist1+24)=(vistorlist){"Chase","Watson"};
    *(vistorlist1+25)=(vistorlist){"Chong","King"};
    *(vistorlist1+26)=(vistorlist){"Colin","Lee"};
    *(vistorlist1+27)=(vistorlist){"Colton","Fox"};
    *(vistorlist1+28)=(vistorlist){"Conrad","Hunt"};
    *(vistorlist1+29)=(vistorlist){"David","Kelly"};
    *(vistorlist1+30)=(vistorlist){"Donald","Trump"};
    *(vistorlist1+31)=(vistorlist){"Donny","Adams"};
    *(vistorlist1+32)=(vistorlist){"Dylan","Allen"};
    *(vistorlist1+33)=(vistorlist){"Earl","Ross"};
    *(vistorlist1+34)=(vistorlist){"Eddie","Owen"};
    *(vistorlist1+35)=(vistorlist){"Edmundo","Mason"};
    *(vistorlist1+36)=(vistorlist){"Edward","Knight"};
    *(vistorlist1+37)=(vistorlist){"Edwin","Butler"};
    *(vistorlist1+38)=(vistorlist){"Elvin","Saunders"};
    *(vistorlist1+39)=(vistorlist){"Gale","Stevens"};
    *(vistorlist1+40)=(vistorlist){"Galen","Webb"};
    *(vistorlist1+41)=(vistorlist){"Hobert","Bradley"};
    *(vistorlist1+42)=(vistorlist){"Jack","Jenkins"};
    *(vistorlist1+43)=(vistorlist){"Jarod","Carter"};
    *(vistorlist1+44)=(vistorlist){"Jerry","Phillips"};
    *(vistorlist1+45)=(vistorlist){"Juan","Mitchell"};
    *(vistorlist1+46)=(vistorlist){"Jude","Anderson"};
    *(vistorlist1+47)=(vistorlist){"Kim","Walsh"};
    *(vistorlist1+48)=(vistorlist){"Leo","Stone"};
    *(vistorlist1+49)=(vistorlist){"Loyd","West"};
    *random_varible=rand()%4;
    int randomnumber1=rand();
    int randomnumber2=rand();
    int randomnumber3=rand();
    int randomnumber4=rand();
    int randomnumber5=rand();
    int randomnumber6=rand();
    if(*random_varible==0)//single room
    {vistor=Initialize(random_varible);
        first=(int)strlen((vistorlist1+(randomnumber1%50))->firstname);
        last=(int)strlen((vistorlist1+(randomnumber2%50))->givenname);
        char* full=malloc(first+last+2);//one for space and another for the symbol at the end of the string.
        memcpy(full,((vistorlist1+(randomnumber1%50))->firstname), first);
        memcpy(full+first+1,((vistorlist1+(randomnumber2%50))->givenname), last+ 1); // +1 to copy the null-terminator
        *(full+first)=' ';//REMEMBER TO RETURN THE MEMORY!!!!
        InsertLastList(&vistor,full);//insert name

        char* id3=malloc(sizeof(char)*9);
        sprintf(id3,"%03u",rand()%1000);
        sprintf((id3+3),"%03u",rand()%1000);
        *(id3+6)='A';
        *(id3+7)='B';
        *(id3+8)='\0';//mark as the end of the ID string;
        InsertLastList(&vistor,id3);//insert ID
        int* key=malloc(sizeof(int));
        *key=rand()%2+1;
        InsertLastList(&vistor,key);//key(may ask 1-2)
        int* breakfast=malloc(sizeof(int));
        int* nights=malloc(sizeof(int));
        *nights=rand()%9+1;
        *breakfast=rand()%2*( *nights);
        InsertLastList(&vistor,breakfast);//key(may ask 0-1)
        InsertLastList(&vistor,nights);//key(may ask 1-9)
    }
    else if (*random_varible==1)//double room
    {vistor=Initialize(random_varible);
        first=(int)strlen((vistorlist1+(randomnumber1%50))->firstname);
        last=(int)strlen((vistorlist1+(randomnumber2%50))->givenname);
        char* full=malloc(first+last+2);//one for space and another for the symbol at the end of the string.
        memcpy(full,((vistorlist1+(randomnumber1%50))->firstname), first);
        memcpy(full+first+1,((vistorlist1+(randomnumber2%50))->givenname), last+ 1); // +1 to copy the null-terminator
        *(full+first)=' ';//REMEMBER TO RETURN THE MEMORY!!!!
        InsertLastList(&vistor,full);//insert name

        char* id3=malloc(sizeof(char)*9);
        sprintf(id3,"%03u",rand()%1000);
        sprintf((id3+3),"%03u",rand()%1000);
        *(id3+6)='A';
        *(id3+7)='B';
        *(id3+8)='\0';
        InsertLastList(&vistor,id3);//insert ID
        first=(int)strlen((vistorlist1+(randomnumber3%50))->firstname);
        last=(int)strlen((vistorlist1+(randomnumber4%50))->givenname);
        char* full2=malloc(first+last+2);//one for space and another for the symbol at the end of the string.
        memcpy(full2,((vistorlist1+(randomnumber3%50))->firstname), first);
        memcpy(full2+first+1,((vistorlist1+(randomnumber4%50))->givenname), last+ 1); // +1 to copy the null-terminator
        *(full2+first)=' ';//REMEMBER TO RETURN THE MEMORY!!!!

        InsertLastList(&vistor,full2);//insert name2
        char* id32=malloc(sizeof(char)*9);
        sprintf(id32,"%03u",rand()%1000);
        sprintf((id32+3),"%03u",rand()%1000);
        *(id32+6)='A';
        *(id32+7)='B';
        *(id32+8)='\0';
        InsertLastList(&vistor,id32);//insert ID2

        int* key=malloc(sizeof(int));
        *key=rand()%2+1;
        InsertLastList(&vistor,key);//key(may ask 1-2)
        int* breakfast=malloc(sizeof(int));
        int* nights=malloc(sizeof(int));
        *nights=rand()%9+1;
        *breakfast=rand()%3*( *nights);
        InsertLastList(&vistor,breakfast);//key(may ask 0-2)
        InsertLastList(&vistor,nights);//key(may ask 1-9)
    }
    else if (*random_varible==2)//family room
    {vistor=Initialize(random_varible);
        first=(int)strlen((vistorlist1+(randomnumber1%50))->firstname);
        last=(int)strlen((vistorlist1+(randomnumber2%50))->givenname);
        char* full=malloc(first+last+2);//one for space and another for the symbol at the end of the string.
        memcpy(full,((vistorlist1+(randomnumber1%50))->firstname), first);
        memcpy(full+first+1,((vistorlist1+(randomnumber2%50))->givenname), last+ 1); // +1 to copy the null-terminator
        *(full+first)=' ';//REMEMBER TO RETURN THE MEMORY!!!!
        InsertLastList(&vistor,full);//insert name

        char* id3=malloc(sizeof(char)*9);
        sprintf(id3,"%03u",rand()%1000);
        sprintf((id3+3),"%03u",rand()%1000);
        *(id3+6)='A';
        *(id3+7)='B';
        *(id3+8)='\0';
        InsertLastList(&vistor,id3);//insert ID
        first=(int)strlen((vistorlist1+(randomnumber3%50))->firstname);
        last=(int)strlen((vistorlist1+(randomnumber4%50))->givenname);
        char* full2=malloc(first+last+2);//one for space and another for the symbol at the end of the string.
        memcpy(full2,((vistorlist1+(randomnumber3%50))->firstname), first);
        memcpy(full2+first+1,((vistorlist1+(randomnumber4%50))->givenname), last+ 1); // +1 to copy the null-terminator
        *(full2+first)=' ';//REMEMBER TO RETURN THE MEMORY!!!!
        InsertLastList(&vistor,full2);//insert name2

        char* id32=malloc(sizeof(char)*9);
        sprintf(id32,"%03u",rand()%1000);
        sprintf((id32+3),"%03u",rand()%1000);
        *(id32+6)='A';
        *(id32+7)='B';
        *(id32+8)='\0';
        InsertLastList(&vistor,id32);//insert ID2
        first=(int)strlen((vistorlist1+(randomnumber5%50))->firstname);
        last=(int)strlen((vistorlist1+(randomnumber6%50))->givenname);
        char* full3=malloc(first+last+2);//one for space and another for the symbol at the end of the string.
        memcpy(full3,((vistorlist1+(randomnumber5%50))->firstname), first);
        memcpy(full3+first+1,((vistorlist1+(randomnumber6%50))->givenname), last+ 1); // +1 to copy the null-terminator
        *(full3+first)=' ';//REMEMBER TO RETURN THE MEMORY!!!!
        InsertLastList(&vistor,full3);//insert name2

        char* id33=malloc(sizeof(char)*9);
        sprintf(id33,"%03u",rand()%1000);
        sprintf((id33+3),"%03u",rand()%1000);
        *(id33+6)='A';
        *(id33+7)='B';
        *(id33+8)='\0';
        InsertLastList(&vistor,id33);//insert ID2
        int* key=malloc(sizeof(int));
        *key=rand()%3+1;
        InsertLastList(&vistor,key);//key(may ask 1-2)
        int* breakfast=malloc(sizeof(int));
        int* nights=malloc(sizeof(int));
        *nights=rand()%9+1;
        *breakfast=(rand()%4)*( *nights);
        InsertLastList(&vistor,breakfast);//key(may ask 0-3)
        InsertLastList(&vistor,nights);//key(may ask 1-9)
    }
    else //dorm
    {vistor=Initialize(random_varible);
        first=(int)strlen((vistorlist1+(randomnumber5%50))->firstname);
        last=(int)strlen((vistorlist1+(randomnumber6%50))->givenname);
        char* full=malloc(first+last+2);//one for space and another for the symbol at the end of the string.
        memcpy(full,((vistorlist1+(randomnumber5%50))->firstname), first);
        memcpy(full+first+1,((vistorlist1+(randomnumber6%50))->givenname), last+ 1); // +1 to copy the null-terminator
        *(full+first)=' ';//REMEMBER TO RETURN THE MEMORY!!!!
        InsertLastList(&vistor,full);//insert name

        char* id3=malloc(sizeof(char)*9);
        sprintf(id3,"%03u",rand()%1000);
        sprintf((id3+3),"%03u",rand()%1000);
        *(id3+6)='A';
        *(id3+7)='B';
        *(id3+8)='\0';
        InsertLastList(&vistor,id3);//insert ID
        int* key=malloc(sizeof(int));
        *key=rand()%2;
        InsertLastList(&vistor,key);//key(may ask 0-1)
        int* breakfast=malloc(sizeof(int));
        int* nights=malloc(sizeof(int));
        *nights=rand()%9+1;
        *breakfast=rand()%2*( *nights);
        InsertLastList(&vistor,breakfast);//breakfast(may ask 0-1)
        InsertLastList(&vistor,nights);//nights(may ask 1-9)

    }
    free(vistorlist1);
    return vistor;
}
