#include "hotel-ll.h"
#include "hotel-mt.h"
#include "hotel-db.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
int main(){
    int A,i,j;
    char* time1= malloc(sizeof(char)*20);
    A=Initialdata();
    if (A==-1)
    { printf("OOps,The system fails to initialize, please contact your system administer for help. :(");
    return 0;}
    printf("-SYSTEM INITIALIZED SUCCESSFULLY\n");
    printf("Welcome to no-star hotel management system,press Enter to start demo");
    getchar();
    printf("Input the current data(the form like 04/06/1989(DATE/MONTH/YEAR)):\n");
    scanf("%s",time1);
    printf("Input the span of days:\n");
            getchar();
    int span;
    scanf("%d",&span);
    node_t* a;
    srand(time(NULL));
    for(i=0;i<span;i++){
    A=rand()%10;
    printf("Today is %s, %d groups of vistors check in:\n",time1,A);//0-9 vistors per day;
    getchar();
    if(i!=0){
    long long int b=timetonumber(time1);//my method to dell with time is not sufficient with type int;
    b=b+i;
    printf("Checkoutlist:\n");
    getchar();
    checkout((int)b);
    time1=numbertotime(b);}
    for(j=0;j<A;j++)
    {a = generatevistors(A+j);
     checkin(a,time1);}
    printf("Options to search available room(NOT AVAILABLE FOR TRIAL VERSION)\n");
    getchar();
    printf("Options to search guests(NOT AVAILABLE DUE TO SAFETY REASON)\n");
    getchar();
    printf("Options to add breakfast,change nights(NOT AVAILABLE FOR TRIAL VERSION))\n");
    getchar();
    printf("press Enter to next day's demo:\n");
    getchar();}
    free(time1);
    FreeList(&a);//return the memory of a//
}//
//set(CMAKE_C_FLAGS "-Wall -Werror")//
